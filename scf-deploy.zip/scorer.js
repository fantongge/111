function scoreHand(imageBase64, mode) {
  const features = extractFeatures(imageBase64);
  const dimensions = {
    handProportion: scoreHandProportion(features),
    fingerStraightness: scoreFingerStraightness(features),
    skinSmoothness: scoreSkinSmoothness(features),
    nailHealth: scoreNailHealth(features),
    skinTone: scoreSkinTone(features)
  };
  if (mode === 'both') {
    dimensions.symmetry = scoreSymmetry(features);
  }
  const total = Object.values(dimensions).reduce((sum, d) => sum + d.score, 0);
  const count = Object.values(dimensions).length;
  const overall = Math.round((total / count) * 10) / 10;
  return {
    overall,
    maxScore: 10,
    dimensions,
    reasons: generateReasons(dimensions),
    suggestions: generateSuggestions(dimensions)
  };
}

function extractFeatures(base64) {
  let hash = 0;
  for (let i = 0; i < Math.min(base64.length, 1000); i++) {
    hash = ((hash << 5) - hash) + base64.charCodeAt(i);
    hash = hash & hash;
  }
  const seed = Math.abs(hash) / 2147483647;
  return {
    fingerLengthRatio: 0.4 + seed * 0.3,
    knuckleAlignment: 0.5 + Math.sin(seed * 10) * 0.3,
    skinTexture: 0.3 + Math.cos(seed * 7) * 0.3,
    nailAspectRatio: 0.5 + Math.sin(seed * 13) * 0.25,
    nailSurface: 0.4 + Math.cos(seed * 17) * 0.3,
    skinHueVariance: 0.1 + seed * 0.4,
    jointDarkness: 0.1 + (1 - seed) * 0.3,
    symmetryScore: 0.6 + Math.sin(seed * 11) * 0.2,
    overallQuality: 0.3 + seed * 0.5
  };
}

function scoreHandProportion(f) {
  const raw = f.fingerLengthRatio;
  const score = raw < 0.55 ? 4 + raw * 8 : raw > 0.65 ? 10 - (raw - 0.65) * 20 : 7 + (raw - 0.55) * 30;
  return { score: Math.round(Math.min(10, Math.max(1, score)) * 10) / 10, detail: describeProportion(raw) };
}

function describeProportion(r) {
  if (r < 0.5) return '手指比例偏短，视觉上偏可爱型';
  if (r < 0.58) return '手指比例适中，标准手型';
  if (r < 0.65) return '手指修长，比例优美';
  return '手指非常修长，适合弹奏乐器等';
}

function scoreFingerStraightness(f) {
  const score = Math.min(10, Math.max(1, f.knuckleAlignment * 10));
  const d = score > 7 ? '手指挺直，线条流畅' : score > 5 ? '手指轻微弯曲，整体尚可' : '手指弯曲较明显';
  return { score: Math.round(score * 10) / 10, detail: d };
}

function scoreSkinSmoothness(f) {
  const raw = 1 - Math.abs(f.skinTexture - 0.5) * 1.2;
  const score = Math.min(10, Math.max(1, raw * 10));
  const d = score > 7 ? '皮肤细腻光滑' : score > 5 ? '皮肤状态一般，有轻微纹理' : '皮肤纹理较明显';
  return { score: Math.round(score * 10) / 10, detail: d };
}

function scoreNailHealth(f) {
  const ratioScore = Math.min(10, Math.max(1, f.nailAspectRatio * 8 + 2));
  const surfaceScore = Math.min(10, Math.max(1, f.nailSurface * 8 + 2));
  const score = (ratioScore + surfaceScore) / 2;
  const d = score > 7 ? '指甲健康，甲型美观' : score > 5 ? '指甲状态中等' : '指甲有可见瑕疵';
  return { score: Math.round(score * 10) / 10, detail: d };
}

function scoreSkinTone(f) {
  const evenScore = Math.min(10, Math.max(1, (1 - f.skinHueVariance) * 10));
  const jointScore = Math.min(10, Math.max(1, (1 - f.jointDarkness) * 10));
  const score = (evenScore + jointScore) / 2;
  const d = score > 7 ? '肤色均匀，关节无暗沉' : score > 5 ? '肤色尚可，关节处略有暗沉' : '肤色不均，建议护理';
  return { score: Math.round(score * 10) / 10, detail: d };
}

function scoreSymmetry(f) {
  const score = Math.min(10, Math.max(1, f.symmetryScore * 10));
  const d = score > 7 ? '双手对称性很好' : score > 5 ? '双手基本对称' : '双手存在可见不对称';
  return { score: Math.round(score * 10) / 10, detail: d };
}

function generateReasons(dims) {
  const reasons = [];
  const sorted = Object.entries(dims).sort((a, b) => b[1].score - a[1].score);
  const best = sorted[0];
  const worst = sorted[sorted.length - 1];

  const dimNames = {
    handProportion: '手型比例', fingerStraightness: '手指直度', skinSmoothness: '皮肤细滑度',
    nailHealth: '指甲健康', skinTone: '肤色均匀度', symmetry: '双手对称性'
  };

  reasons.push('[BEST] ' + dimNames[best[0]] + ' - ' + best[1].score + '分（' + best[1].detail + '）');
  reasons.push('[WORST] ' + dimNames[worst[0]] + ' - ' + worst[1].score + '分（' + worst[1].detail + '）');

  if (dims.handProportion.score < 6) reasons.push('[TIP] 手指比例偏短/偏长，可通过甲型修饰视觉改善');
  if (dims.skinSmoothness.score < 6) reasons.push('[TIP] 皮肤纹理较明显，建议加强日常护手');
  if (dims.nailHealth.score < 6) reasons.push('[TIP] 指甲状态需关注，保持修剪和护理');
  if (dims.skinTone.score < 6) reasons.push('[TIP] 肤色均匀度偏低，可尝试美白护手产品');

  return reasons;
}

function generateSuggestions(dims) {
  const suggestions = [];
  if (dims.handProportion.score < 7) {
    suggestions.push({ item: '甲型修饰', desc: '选择椭圆或杏仁形甲型，视觉上拉长手指' });
  }
  if (dims.skinSmoothness.score < 7) {
    suggestions.push({ item: '手部保湿', desc: '每天使用护手霜，每周做一次手膜' });
  }
  if (dims.nailHealth.score < 7) {
    suggestions.push({ item: '指甲护理', desc: '定期修剪死皮，使用强化底油' });
  }
  if (dims.skinTone.score < 7) {
    suggestions.push({ item: '美白护理', desc: '注意防晒，使用含维生素C的护手产品' });
  }
  if (dims.fingerStraightness && dims.fingerStraightness.score < 7) {
    suggestions.push({ item: '手部拉伸', desc: '每日做手指拉伸运动，改善柔韧性' });
  }
  if (suggestions.length === 0) {
    suggestions.push({ item: '继续保持', desc: '你的手部状态非常好，继续保持日常护理！' });
  }
  return suggestions;
}

module.exports = { scoreHand };
