const http = require("http");
const https = require("https");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const urlMod = require("url");
const scorer = require("./scorer");

const COS_REGION = process.env.COS_REGION || "ap-guangzhou";
const COS_BUCKET = process.env.COS_BUCKET || "handscorer-data-1250000000";
const COS_IMG_BUCKET = process.env.COS_IMG_BUCKET || "handscorer-img-1250000000";
const PORT = parseInt(process.env.SCF_RUNTIME_API_PORT || process.env.PORT || "9000");

function sha1(s) { return crypto.createHash("sha1").update(s).digest("hex"); }
function hmacSha1(k, s) { return crypto.createHmac("sha1", k).update(s).digest("hex"); }

function cosAuth(method, cosPath, headers) {
  const sid = process.env.TENCENTCLOUD_SECRETID;
  const sk = process.env.TENCENTCLOUD_SECRETKEY;
  const now = Math.floor(Date.now() / 1000);
  const kt = now - 60 + ";" + (now + 600);
  const signKey = hmacSha1(sk, kt);
  const hdrKeys = Object.keys(headers).sort();
  const hdrStr = hdrKeys.map(k => k.toLowerCase() + "=" + headers[k]).join("&");
  const httpStr = method + "\n" + cosPath + "\n\n" + hdrStr + "\n";
  const sts = "sha1\n" + kt + "\n" + sha1(httpStr) + "\n";
  const sig = hmacSha1(signKey, sts);
  return "q-sign-algorithm=sha1&q-ak=" + sid + "&q-sign-time=" + kt + "&q-key-time=" + kt + "&q-header-list=" + hdrKeys.join(";") + "&q-url-param-list=&q-signature=" + sig;
}

function cosReq(method, bucket, region, key, body) {
  return new Promise((resolve, reject) => {
    const host = bucket + ".cos." + region + ".myqcloud.com";
    const hdrs = { Host: host };
    if (process.env.TENCENTCLOUD_SESSIONTOKEN) hdrs["x-cos-security-token"] = process.env.TENCENTCLOUD_SESSIONTOKEN;
    hdrs.Authorization = cosAuth(method, key, hdrs);
    const opts = { hostname: host, path: key, method, headers: hdrs, rejectUnauthorized: false };
    const req = https.request(opts, (res) => {
      let data = "";
      res.on("data", c => data += c.toString());
      res.on("end", () => resolve({ status: res.statusCode, data }));
    });
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}
function cosGet(bucket, region, key) { return cosReq("GET", bucket, region, key); }
function cosPut(bucket, region, key, body) { return cosReq("PUT", bucket, region, key, body); }

async function readDB() {
  try { const r = await cosGet(COS_BUCKET, COS_REGION, "/data.json"); if (r.status === 200) return JSON.parse(r.data); } catch (e) {}
  return { users: [], orders: [], reports: [], codes: [], stats: { totalOrders: 0, totalRevenue: 0, totalScored: 0 } };
}
async function writeDB(d) { await cosPut(COS_BUCKET, COS_REGION, "/data.json", JSON.stringify(d)); }

const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg" };

function adminToken() { return "admin-token-" + crypto.createHash("md5").update("hand666").digest("hex"); }

function sendJSON(res, data, code) {
  res.writeHead(code || 200, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
  res.end(JSON.stringify(data));
}
function sendError(res, msg, code) { sendJSON(res, { error: msg }, code || 400); }

async function handler(req, res) {
  try {
    const method = req.method;
    const parsed = urlMod.parse(req.url, true);
    const pathname = parsed.pathname;
    const query = parsed.query;
    const headers = req.headers;

    // Read body
    const bodyStr = await new Promise((resolve) => {
      let data = "";
      req.on("data", c => data += c.toString());
      req.on("end", () => resolve(data));
    });
    let body = {};
    try { body = JSON.parse(bodyStr); } catch (e) { body = {}; }

    // Serve static files
    const staticRoutes = {
      "/": "public/user/index.html",
      "/admin": "public/admin/dashboard.html",
      "/admin/": "public/admin/dashboard.html",
      "/user/index.html": "public/user/index.html",
      "/user/report.html": "public/user/report.html",
      "/admin/login.html": "public/admin/login.html",
      "/admin/dashboard.html": "public/admin/dashboard.html",
      "/admin/orders.html": "public/admin/orders.html",
      "/admin/images.html": "public/admin/images.html",
      "/admin/codes.html": "public/admin/codes.html",
    };
    if (staticRoutes[pathname]) { return serveFile(res, staticRoutes[pathname]); }
    if (pathname.startsWith("/admin/") && !pathname.startsWith("/api/")) { return serveFile(res, "public" + pathname); }

    // === User APIs ===

    // Upload
    if (pathname === "/api/user/upload" && method === "POST") {
      if (!body.image) return sendError(res, "请上传手部照片");
      const orderId = "ORD" + Date.now().toString(36).toUpperCase();
      const userId = body.userId || ("user_" + Date.now().toString(36));
      const imgName = orderId + ".png";
      const b64 = body.image.replace(/^data:image\/\w+;base64,/, "");
      const buf = Buffer.from(b64, "base64");
      const upRes = await cosPut(COS_IMG_BUCKET, COS_REGION, "/" + imgName, buf);
      if (upRes.status >= 400) return sendError(res, "上传图片失败:" + upRes.status, 500);
      const imgUrl = "https://" + COS_IMG_BUCKET + ".cos." + COS_REGION + ".myqcloud.com/" + imgName;
      const db = await readDB();
      const order = { orderId, userId, image: imgUrl, mode: body.mode || "single", status: "pending", amount: 9.9, paymentMethod: null, paidAt: null, createdAt: new Date().toISOString() };
      db.orders.push(order);
      db.stats.totalOrders++;
      await writeDB(db);
      return sendJSON(res, { orderId, userId, amount: 9.9 });
    }

    // Pay
    if (pathname === "/api/user/pay" && method === "POST") {
      if (!body.orderId) return sendError(res, "缺少订单号");
      const db = await readDB();
      const order = db.orders.find(o => o.orderId === body.orderId);
      if (!order) return sendError(res, "订单不存在", 404);
      if (order.status !== "pending") return sendError(res, "订单已处理");
      if (body.method === "code") {
        if (!body.code) return sendError(res, "请输入兑换码");
        const c = db.codes.find(c => c.code === body.code.trim().toUpperCase() && !c.used);
        if (!c) return sendError(res, "兑换码无效或已使用");
        c.used = true; c.usedAt = new Date().toISOString();
      }
      order.status = "paid"; order.paymentMethod = body.method || "wechat"; order.paidAt = new Date().toISOString();
      order.transactionId = "WX" + Date.now();
      await writeDB(db);

      // AI Score
      const imgKey = order.image.split("/").pop();
      const imgRes = await cosGet(COS_IMG_BUCKET, COS_REGION, "/" + imgKey);
      const b64data = imgRes.status === 200 ? Buffer.from(imgRes.data).toString("base64") : "";
      const report = scorer.scoreHand(b64data, order.mode);
      const saved = { id: "RPT" + Date.now().toString(36).toUpperCase(), orderId: body.orderId, userId: order.userId, mode: order.mode, ...report, createdAt: new Date().toISOString() };
      db.reports.push(saved);
      db.stats.totalScored++;
      await writeDB(db);
      return sendJSON(res, { success: true, reportId: saved.id });
    }

    // Get report
    if (pathname === "/api/user/report" && method === "GET") {
      if (!query.id) return sendError(res, "缺少报告ID");
      const db = await readDB();
      const r = db.reports.find(r => r.id === query.id);
      if (!r) return sendError(res, "报告不存在", 404);
      return sendJSON(res, r);
    }

    // === Admin APIs ===
    function checkAdmin(h) {
      const auth = (h["authorization"] || "").replace("Bearer ", "");
      return auth === adminToken();
    }
    if (!checkAdmin(headers)) return sendError(res, "未登录", 401);

    if (pathname === "/api/admin/login" && method === "POST") {
      if (body.username === "admin" && body.password === "hand666") return sendJSON(res, { success: true, token: adminToken() });
      return sendError(res, "账号或密码错误", 401);
    }
    if (pathname === "/api/admin/stats" && method === "GET") {
      const db = await readDB();
      return sendJSON(res, db.stats);
    }
    if (pathname === "/api/admin/orders" && method === "GET") {
      const db = await readDB();
      const orders = db.orders.map(o => ({ ...o, report: db.reports.find(r => r.orderId === o.orderId) || null }));
      return sendJSON(res, orders);
    }
    if (pathname === "/api/admin/codes") {
      if (method === "GET") { const db = await readDB(); return sendJSON(res, db.codes); }
      if (method === "POST") {
        const db = await readDB();
        const count = body.count || 10; const prefix = body.prefix || "HAND";
        const codes = [];
        for (let i = 0; i < count; i++) {
          codes.push({ code: prefix + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase(), used: false, usedBy: null, usedAt: null, createdAt: new Date().toISOString() });
        }
        db.codes.push(...codes);
        await writeDB(db);
        return sendJSON(res, { success: true, count, codes: codes.map(c => c.code) });
      }
    }
    if (pathname === "/api/admin/codes/delete" && method === "POST") {
      if (!body.code) return sendError(res, "缺少兑换码");
      const db = await readDB();
      const idx = db.codes.findIndex(c => c.code === body.code);
      if (idx === -1) return sendError(res, "兑换码不存在", 404);
      db.codes.splice(idx, 1);
      await writeDB(db);
      return sendJSON(res, { success: true });
    }

    // Image redirect
    if (pathname.startsWith("/uploads/")) {
      const n = pathname.replace("/uploads/", "");
      res.writeHead(302, { Location: "https://" + COS_IMG_BUCKET + ".cos." + COS_REGION + ".myqcloud.com/" + n });
      return res.end();
    }

    return sendError(res, "Not Found: " + pathname, 404);
  } catch (e) {
    return sendError(res, e.message, 500);
  }
}

function serveFile(res, fp) {
  try {
    const c = fs.readFileSync(path.join(__dirname, fp), "utf8");
    const ext = path.extname(fp).toLowerCase();
    res.writeHead(200, { "Content-Type": MIME[ext] || "text/html; charset=utf-8", "Access-Control-Allow-Origin": "*" });
    res.end(c);
  } catch (e) {
    sendError(res, "File not found", 404);
  }
}

// Create and start server
const server = http.createServer(handler);
server.listen(PORT, "0.0.0.0", () => {
  console.log("Hand Scorer server running on port " + PORT);
});
